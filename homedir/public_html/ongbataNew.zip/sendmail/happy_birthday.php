
<?php 
# key Firebase notification 
define('API_ACCESS_KEY','AAAAZ_VOsLM:APA91bG0SCpjhZlWfcp6EQqGmFP1t1ha2Tk3g33ISWs2Eb3oDsJ8rJENS0lXiKDOBO8C8j0sZqYs_l00HHz1jb-bXNlHmoJQIOhU6RoR0p53DpTn4BE27385L5ZFBI_l6mLLK_Ies5Dy');
/* Send mail */
include 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendEmail($userMail, $mailSubject, $mailBody)
{
    $mail = new PHPMailer();
    try {
            $mail->CharSet = 'UTF-8';
            $mail->IsSMTP();
            $mail->Mailer = "smtp";
        
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = "tls";
            $mail->Port = 587;
            $mail->Host = "smtp.gmail.com";
            $mail->Username = 'toidayhoc@datdia.com';
            $mail->Password = "oqrssuhwhpzxudug";
            //Content
            $mail->IsHTML(true);
            $mail->addAddress($userMail);
            $mail->SetFrom("Ongbatavn@gmail.com", "Phần mềm gia phả Ongbata");
            $mail->AddCC('toidayhoc@datdia.com');
            $mail->Subject = $mailSubject;
            $mail->Body = $mailBody;
            
            $sendMailres = ($mail->Send()) ? true : false;
            $mail->clearAllRecipients();
            if ($sendMailres === true) {
                echo "<span style='color: green'>Mail sent successfully</span>";
            } else {
                echo "<span style='color: red'>Mail failed</span>";
            }
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}


/* //  send nofication firebase */
function sendNotif($token, $notif)
{
     $extraNotificationData = ["message" => $notif,"moredata" =>'dd'];
     $fcmNotification = [
        'to'        => $token, //single token
        'notification' => $notif,
        'data' => $extraNotificationData
    ];
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
     $headers = array();
     $headers[] = 'Authorization: Key='.API_ACCESS_KEY;/* Server key */
     $headers[] = 'Content-Type: application/json';
     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
     
     $result = curl_exec($ch);
     if (curl_errno($ch)) {
         echo 'Error:' . curl_error($ch);
     }
     curl_close($ch);
     echo $result.'<br>';
}

/* connect database */
function getData($select = '*', $from, $join = '', $where ='')
{
    $conn = mysqli_connect("localhost","giaphaobt_user","Qtthuchien2021","giaphaobt_data");
    $data = $conn->query('SELECT '.$select.' FROM '.$from .$join.(empty($where)?'':'WHERE'.$where));
    return $data;
}

//select all member
$select = 'author , firstname, lastname, birthdate';
$from = ' ftree_v1_4_members mem ';
$where = ' mem.birthdate != 0 ';
foreach(getData($select, $from, $join, $where) as $dt)
{

    $birthday_user =  date('m-d',$dt['birthdate']);
   if (date('m-d') == $birthday_user) {
      makeEmail($dt['firstname'], $dt['lastname'], $dt['author'], $dt['birthdate']);
      makeToken($dt['author'], $dt['lastname'].' '.$dt['firstname'], $dt['birthdate']);
   }
}

//select email, token
function makeEmail($firstname, $lastname, $id, $date )
{
    $select = 'mem.birthdate, mem.email, fam.name as family_name, u.email as gmail_of_user ';
    $from = ' ftree_v1_4_members mem ';
    $join = ' INNER JOIN ftree_v1_4_families fam on fam.id = mem.family
    INNER JOIN ftree_v1_4_users u on u.id = mem.author ';
    $where =" mem.author = ".$id."";
    foreach(getData($select, $from, $join, $where) as $st)
    {
        $family  = $st['family_name'];
        if ($date == $st['birthdate']) {
            $name = 'Bạn';
        }
        else{
            $name = $lastname . ' ' . $firstname;
        }
        if (!empty($st['email'])) {
            $mailSubject = 'Thông báo sinh nhật';
            ob_start();
            include('content_mail.php');
            $mailBody = ob_get_clean();
            sendEmail($st['email'], $mailSubject, $mailBody);
        }

    }
    if (!empty($st['gmail_of_user']))
    {
            $mailSubject = 'Thông báo sinh nhật';
            ob_start();
            include('content_mail.php');
            $mailBody = ob_get_clean();
            sendEmail($st['gmail_of_user'], $mailSubject, $mailBody);
    }
}

function makeToken($id, $name, $date)
{
    $select = 't.token, f.name';
    $from = ' ftree_v1_4_token_user t ';
    $where =" userid = ".$id."";
    $join = ' INNER JOIN ftree_v1_4_families f on  f.author = t.userid ';
    foreach(getData($select, $from, $join, $where) as $tk)
    {
        $notification = array(
            'title' => 'giapha.ongbata.vn',
            'body' => 'Hôm nay là ngày sinh nhật của '. $name .' trong gia phả ' .$tk['name'] .' ngày ' .date('d/m/Y', $date),
            'icon' => 'https://giapha.ongbata.vn/sendmail/images/isolated-happy-birthday-icon-vector-24974336.jpg',
            'sound' => 1,
            'click_action' => 'https://giapha.ongbata.vn/'
        );
        sendNotif($tk['token'], $notification);
    }
    
}
