<?php 
$servername = "localhost";
$database = "demoongbata_data";
$username = "demoongbata_user";
$password = "Qtthuchien2021";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>