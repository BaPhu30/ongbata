<?php
        // require "amlich.php";
        // require "send-email.php";
        // require "config.php";
        // require "weekday.php";
        // require "../configs/clan_calling.class.php";
?>
<?php 
# key Firebase notification 
define('API_ACCESS_KEY','AAAAZ_VOsLM:APA91bG0SCpjhZlWfcp6EQqGmFP1t1ha2Tk3g33ISWs2Eb3oDsJ8rJENS0lXiKDOBO8C8j0sZqYs_l00HHz1jb-bXNlHmoJQIOhU6RoR0p53DpTn4BE27385L5ZFBI_l6mLLK_Ies5Dy');

/* Send mail */
include 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendEmail($userMail, $mailSubject, $mailBody)
{
    $mail = new PHPMailer();
    try {
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER;    
            $mail->CharSet = 'UTF-8';
            $mail->IsSMTP();
            $mail->Mailer = "smtp";
        
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = "tls";
            $mail->Port = 587;
            $mail->Host = "smtp.gmail.com";
            $mail->Username = 'toidayhoc@datdia.com';
            $mail->Password = "oqrssuhwhpzxudug";
        
            //Attachments
            // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
        
            //Content
            $mail->IsHTML(true);
            $mail->addAddress($userMail);
            $mail->SetFrom("Ongbatavn@gmail.com", "Phần mềm gia phả Ongbata");
            $mail->AddCC('toidayhoc@datdia.com');
            $mail->Subject = $mailSubject;
            $mail->Body = $mailBody;
            
            $sendMailres = ($mail->Send()) ? true : false;
            $mail->clearAllRecipients();
            // return $sendMailres;
            if ($sendMailres === true) {
                echo "<span style='color: green'>Mail sent successfully</span>";
            } else {
                echo "<span style='color: red'>Mail failed</span>";
            }
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

/* Am lich */
function INT($d)
{
    return floor($d);
}
function jdFromDate($dd, $mm, $yy)
{
    $a = INT((14 - $mm) / 12);
    $y = $yy + 4800 - $a;
    $m = $mm + 12 * $a - 3;
    $jd = $dd + INT((153 * $m + 2) / 5) + 365 * $y + INT($y / 4) - INT($y / 100) + INT($y / 400) - 32045;
    if ($jd < 2299161) {
        $jd = $dd + INT((153 * $m + 2) / 5) + 365 * $y + INT($y / 4) - 32083;
    }
    return $jd;
}

function jdToDate($jd)
{
    if ($jd > 2299160) { // After 5/10/1582, Gregorian calendar
        $a = $jd + 32044;
        $b = INT((4 * $a + 3) / 146097);
        $c = $a - INT(($b * 146097) / 4);
    } else {
        $b = 0;
        $c = $jd + 32082;
    }
    $d = INT((4 * $c + 3) / 1461);
    $e = $c - INT((1461 * $d) / 4);
    $m = INT((5 * $e + 2) / 153);
    $day = $e - INT((153 * $m + 2) / 5) + 1;
    $month = $m + 3 - 12 * INT($m / 10);
    $year = $b * 100 + $d - 4800 + INT($m / 10);
    //echo "day = $day, month = $month, year = $year\n";
    return array($day, $month, $year);
}

function getNewMoonDay($k, $timeZone)
{
    $T = $k / 1236.85; // Time in Julian centuries from 1900 January 0.5
    $T2 = $T * $T;
    $T3 = $T2 * $T;
    $dr = M_PI / 180;
    $Jd1 = 2415020.75933 + 29.53058868 * $k + 0.0001178 * $T2 - 0.000000155 * $T3;
    $Jd1 = $Jd1 + 0.00033 * sin((166.56 + 132.87 * $T - 0.009173 * $T2) * $dr); // Mean new moon
    $M = 359.2242 + 29.10535608 * $k - 0.0000333 * $T2 - 0.00000347 * $T3; // Sun's mean anomaly
    $Mpr = 306.0253 + 385.81691806 * $k + 0.0107306 * $T2 + 0.00001236 * $T3; // Moon's mean anomaly
    $F = 21.2964 + 390.67050646 * $k - 0.0016528 * $T2 - 0.00000239 * $T3; // Moon's argument of latitude
    $C1 = (0.1734 - 0.000393 * $T) * sin($M * $dr) + 0.0021 * sin(2 * $dr * $M);
    $C1 = $C1 - 0.4068 * sin($Mpr * $dr) + 0.0161 * sin($dr * 2 * $Mpr);
    $C1 = $C1 - 0.0004 * sin($dr * 3 * $Mpr);
    $C1 = $C1 + 0.0104 * sin($dr * 2 * $F) - 0.0051 * sin($dr * ($M + $Mpr));
    $C1 = $C1 - 0.0074 * sin($dr * ($M - $Mpr)) + 0.0004 * sin($dr * (2 * $F + $M));
    $C1 = $C1 - 0.0004 * sin($dr * (2 * $F - $M)) - 0.0006 * sin($dr * (2 * $F + $Mpr));
    $C1 = $C1 + 0.0010 * sin($dr * (2 * $F - $Mpr)) + 0.0005 * sin($dr * (2 * $Mpr + $M));
    if ($T < -11) {
        $deltat = 0.001 + 0.000839 * $T + 0.0002261 * $T2 - 0.00000845 * $T3 - 0.000000081 * $T * $T3;
    } else {
        $deltat = -0.000278 + 0.000265 * $T + 0.000262 * $T2;
    };
    $JdNew = $Jd1 + $C1 - $deltat;
    //echo "JdNew = $JdNew\n";
    return INT($JdNew + 0.5 + $timeZone / 24);
}

function getSunLongitude($jdn, $timeZone)
{
    $T = ($jdn - 2451545.5 - $timeZone / 24) / 36525; // Time in Julian centuries from 2000-01-01 12:00:00 GMT
    $T2 = $T * $T;
    $dr = M_PI / 180; // degree to radian
    $M = 357.52910 + 35999.05030 * $T - 0.0001559 * $T2 - 0.00000048 * $T * $T2; // mean anomaly, degree
    $L0 = 280.46645 + 36000.76983 * $T + 0.0003032 * $T2; // mean longitude, degree
    $DL = (1.914600 - 0.004817 * $T - 0.000014 * $T2) * sin($dr * $M);
    $DL = $DL + (0.019993 - 0.000101 * $T) * sin($dr * 2 * $M) + 0.000290 * sin($dr * 3 * $M);
    $L = $L0 + $DL; // true longitude, degree
    //echo "\ndr = $dr, M = $M, T = $T, DL = $DL, L = $L, L0 = $L0\n";
    $L = $L * $dr;
    $L = $L - M_PI * 2 * (INT($L / (M_PI * 2))); // Normalize to (0, 2*PI)
    return INT($L / M_PI * 6);
}

function getLunarMonth11($yy, $timeZone)
{
    $off = jdFromDate(31, 12, $yy) - 2415021;
    $k = INT($off / 29.530588853);
    $nm = getNewMoonDay($k, $timeZone);
    $sunLong = getSunLongitude($nm, $timeZone); // sun longitude at local midnight
    if ($sunLong >= 9) {
        $nm = getNewMoonDay($k - 1, $timeZone);
    }
    return $nm;
}

function getLeapMonthOffset($a11, $timeZone)
{
    $k = INT(($a11 - 2415021.076998695) / 29.530588853 + 0.5);
    $last = 0;
    $i = 1; // We start with the month following lunar month 11
    $arc = getSunLongitude(getNewMoonDay($k + $i, $timeZone), $timeZone);
    do {
        $last = $arc;
        $i = $i + 1;
        $arc = getSunLongitude(getNewMoonDay($k + $i, $timeZone), $timeZone);
    } while ($arc != $last && $i < 14);
    return $i - 1;
}

/* Comvert solar date dd/mm/yyyy to the corresponding lunar date */
function convertSolar2Lunar($dd, $mm, $yy, $timeZone)
{
    $dayNumber = jdFromDate($dd, $mm, $yy);
    $k = INT(($dayNumber - 2415021.076998695) / 29.530588853);
    $monthStart = getNewMoonDay($k + 1, $timeZone);
    if ($monthStart > $dayNumber) {
        $monthStart = getNewMoonDay($k, $timeZone);
    }
    $a11 = getLunarMonth11($yy, $timeZone);
    $b11 = $a11;
    if ($a11 >= $monthStart) {
        $lunarYear = $yy;
        $a11 = getLunarMonth11($yy - 1, $timeZone);
    } else {
        $lunarYear = $yy + 1;
        $b11 = getLunarMonth11($yy + 1, $timeZone);
    }
    $lunarDay = $dayNumber - $monthStart + 1;
    $diff = INT(($monthStart - $a11) / 29);
    $lunarLeap = 0;
    $lunarMonth = $diff + 11;
    if ($b11 - $a11 > 365) {
        $leapMonthDiff = getLeapMonthOffset($a11, $timeZone);
        if ($diff >= $leapMonthDiff) {
            $lunarMonth = $diff + 10;
            if ($diff == $leapMonthDiff) {
                $lunarLeap = 1;
            }
        }
    }
    if ($lunarMonth > 12) {
        $lunarMonth = $lunarMonth - 12;
    }
    if ($lunarMonth >= 11 && $diff < 4) {
        $lunarYear -= 1;
    }
    return array($lunarDay, $lunarMonth, $lunarYear, $lunarLeap);
}

/* Convert a lunar date to the corresponding solar date */
function convertLunar2Solar($lunarDay, $lunarMonth, $lunarYear, $lunarLeap, $timeZone)
{
    if ($lunarMonth < 11) {
        $a11 = getLunarMonth11($lunarYear - 1, $timeZone);
        $b11 = getLunarMonth11($lunarYear, $timeZone);
    } else {
        $a11 = getLunarMonth11($lunarYear, $timeZone);
        $b11 = getLunarMonth11($lunarYear + 1, $timeZone);
    }
    $k = INT(0.5 + ($a11 - 2415021.076998695) / 29.530588853);
    $off = $lunarMonth - 11;
    if ($off < 0) {
        $off += 12;
    }
    if ($b11 - $a11 > 365) {
        $leapOff = getLeapMonthOffset($a11, $timeZone);
        $leapMonth = $leapOff - 2;
        if ($leapMonth < 0) {
            $leapMonth += 12;
        }
        if ($lunarLeap != 0 && $lunarMonth != $leapMonth) {
            return array(0, 0, 0);
        } else if ($lunarLeap != 0 || $off >= $leapOff) {
            $off += 1;
        }
    }
    $monthStart = getNewMoonDay($k + $off, $timeZone);
    return jdToDate($monthStart + $lunarDay - 1);
}

function alhn()
{
    $arr = array_slice(convertSolar2Lunar(date('d'), date('m'), date('Y'), 7), 0, 3);
    $arr[0] = str_pad($arr[0], 2, '0', STR_PAD_LEFT);
    $arr[1] = str_pad($arr[1], 2, '0', STR_PAD_LEFT);
    return implode("-", $arr);
}
/* weekday */
$weekday = date("l");
$weekday = strtolower($weekday);
switch($weekday) {
	case 'monday':
		$weekday = 'Thứ hai';
		break;
	case 'tuesday':
		$weekday = 'Thứ ba';
		break;
	case 'wednesday':
		$weekday = 'Thứ tư';
		break;
	case 'thursday':
		$weekday = 'Thứ năm';
		break;
	case 'friday':
		$weekday = 'Thứ sáu';
		break;
	case 'saturday':
		$weekday = 'Thứ bảy';
		break;
	default:
		$weekday = 'Chủ nhật';
		break;
}
/* //  send nofication firebase */
function sendNotif($token, $notif){
     $feilds = array('registration_ids'=>$token, 'notification'=>$notif);
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($feilds));
     $headers = array();
     $headers[] = 'Authorization: Key='.API_ACCESS_KEY;/* Server key */
     $headers[] = 'Content-Type: application/json';
     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
     
     $result = curl_exec($ch);
     if (curl_errno($ch)) {
         echo 'Error:' . curl_error($ch);
     }
     curl_close($ch);
     echo $result.'<br>';
 }

/* connect database */
$conn = mysqli_connect("localhost","giaphaobt_user","Qtthuchien2021","giaphaobt_data");
// sendEmail('giapho.06082000@gmail.com', 'test', 'hehe');

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send mail</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h3 class="text-center mt-5">Gửi email thông báo ngày giỗ</h3>
        <?php 
        $url_profile = 'https://giapha.ongbata.vn/ong_ba_ta-profice/index/profile-ongbata.php?id=';
        $today_lunar = alhn();
        // $today_lunar = '03-07-2021';
        $today_lunar_day = explode("-", $today_lunar)[0];
        $today_lunar_month = explode("-", $today_lunar)[1];
        $today_lunar_year = explode("-", $today_lunar)[2];
        date_default_timezone_set("Asia/Ho_Chi_Minh"); 
        $solarDay = date("d");
        $solarMonth = date("m");
        $solarYear = date("Y");

        echo "<h5>Âm lịch hôm nay là: $weekday, ngày $today_lunar</h5>";
        // send notification full moon day
        $data = "SELECT ftree_v1_4_users.username, ftree_v1_4_users.email, ftree_v1_4_token_user.token FROM ftree_v1_4_users JOIN ftree_v1_4_token_user ON ftree_v1_4_users.id = ftree_v1_4_token_user.userid";
            if ($members = mysqli_query($conn, $data)) {
                $token_send = [];
                while ($member = mysqli_fetch_array($members)) {
                    $fullName = $member['username'];
                    $userMail = $member['email'];
                    $tokens = $member['token'];
                    // send notification full moon day
                    if ($today_lunar_day == 14 || $today_lunar_day == 29) {
                        $notification = array(
                            'title' => 'giapha.ongbata.vn',
                            'body' => 'Thông báo sắp tới ngày rằm',
                            'icon' => 'https://ongbata.vn/wp-content/uploads/2021/02/logo-300x300.png',
                            'sound' => 'mySound',
                            'click_action' => 'https://giapha.ongbata.vn/'
                        );
                       
                         array_push($token_send,$tokens);
                    }
                }
                if(!empty($token_send)){
                     sendNotif($token_send, $notification);
                }
            }
        // lọc member sắp tới ngày giỗ
        $data = "SELECT ftree_v1_4_members.id, ftree_v1_4_members.lastname,ftree_v1_4_members.firstname,ftree_v1_4_members.photo,ftree_v1_4_users.username, ftree_v1_4_users.email, ftree_v1_4_token_user.token, ftree_v1_4_members.deathdate,
            CASE
                WHEN ftree_v1_4_members.deathdate = 0 THEN Null
                ELSE ftree_v1_4_members.deathdate
                END AS deathdate
            FROM ftree_v1_4_users 
            INNER JOIN ftree_v1_4_token_user ON ftree_v1_4_token_user.userid = ftree_v1_4_users.id 
            INNER JOIN ftree_v1_4_members ON ftree_v1_4_members.author = ftree_v1_4_users.id";

        if ($members = mysqli_query($conn, $data)) {
            echo '<h5>Members sắp đến ngày giỗ: </h5>';
            $token_send2=[];
            while ($member = mysqli_fetch_array($members)) {
                $death_date = date("d-m-Y", $member['deathdate']);
                $death_date_compare = substr($death_date, 0, 5);
                $firstname = $member['firstname'];
                $lastname = $member['lastname'];
                $photo = $member['photo'];
                $tokenUser = $member['token'];
                $id = $member['id'];

                for ($i = 0; $i <= 7; $i++) {
                    $send_date = strtotime("+$i day", strtotime($today_lunar));
                    $send_date = date('d-m', $send_date);
                    if ($death_date_compare == $send_date) {

                        if ($i == 0) {
                            echo "- Hôm nay ngày giỗ của Thành viên <b> $firstname $lastname </b>, ngày $death_date âm lịch.<br/>";
                            $body = 'Hôm nay ngày giỗ của thành viên '.$firstname.' '.$lastname.', ngày '.$death_date.' âm lịch.';
                            if(!empty($tokenUser)){
                                $notification = array(
                                    'title' => 'giapha.ongbata.vn',
                                    'body' => $body,
                                    'icon' => 'https://ongbata.vn/wp-content/uploads/2021/02/logo-300x300.png',
                                    'sound' => 1,
                                    'click_action' => $url_profile.$id
                                );
                                array_push($token_send2,$tokenUser);
                                // sendNotif($tokenUser, $notification);
                            }
                        } else {
                            echo "- Còn $i ngày nữa là đến ngày giỗ của Thành viên <b> $firstname $lastname </b>, ngày $death_date âm lịch.<br/>";
                            $body = 'Còn '.$i.' ngày nữa là đến ngày giỗ của thành viên '.$firstname.' '.$lastname.', ngày '.$death_date.' âm lịch.';
                              if(!empty($tokenUser)){
                                $notification = array(
                                    'title' => 'giapha.ongbata.vn',
                                    'body' => $body,
                                    'icon' => 'https://ongbata.vn/wp-content/uploads/2021/02/logo-300x300.png',
                                    'sound' => 1,
                                    'click_action' => $url_profile.$id
                                );
                                array_push($token_send2,$tokenUser);
                            //  sendNotif($tokenUser, $notification);
                              }

                        }
                    }
                }
            }
            if(!empty($token_send2)){
                 sendNotif($token_send2, $notification);
            }
            if ($count == 0) {
                echo "- Không có member nào có ngày giỗ trong 7 ngày tới";
            } else {
                echo '
                <form class="mt-4" action="" method="post">
                <button class="btn btn-primary" type="submit" name="sendmail">Send Mail</button>
                </form>
                ';
            }
        }
        echo "<br>";

        // sendmail
            $sql_mail ='SELECT ftree_v1_4_members.id, ftree_v1_4_members.lastname,ftree_v1_4_members.firstname,ftree_v1_4_members.photo,ftree_v1_4_members.gender,ftree_v1_4_users.username, ftree_v1_4_users.email, ftree_v1_4_members.deathdate,
                        CASE
                            WHEN ftree_v1_4_members.deathdate = 0 THEN Null
                            ELSE ftree_v1_4_members.deathdate
                            END AS deathdate
                        FROM ftree_v1_4_users 
                        INNER JOIN ftree_v1_4_members ON ftree_v1_4_members.author = ftree_v1_4_users.id';
            if ($members = mysqli_query($conn, $sql_mail)) {
                $count = 0;
                while ($member = mysqli_fetch_array($members)) {
                    $death_date =date("d-m-Y", $member['deathdate']);
                    $death_date_compare = substr($death_date, 0, 5);
                    $firstname = $member['firstname'];
                    $lastname = $member['lastname'];
                    $photo = $member['photo'];
                    $gender = $member['gender'];
                    $link_profile_email = $url_profile . $member['id'];
                    if ($photo == '') {
                        switch ($gender) {
                            case '0':
                                $link_photo = 'https://labtoidayhoc.s3.ap-southeast-1.amazonaws.com/giapnguyen/5049207_avatar_people_person_profile_user_icon.png';
                                break;
                            case '1':
                                $link_photo = 'https://labtoidayhoc.s3.ap-southeast-1.amazonaws.com/giapnguyen/628297_avatar_grandmother_mature_old_person_icon.png';
                                break;
                            case '2':
                                $link_photo = 'https://labtoidayhoc.s3.ap-southeast-1.amazonaws.com/giapnguyen/628283_avatar_grandfather_male_man_mature_icon.png';
                                break;
                        }
                    } else {
                        $link_photo = "https://demo.ongbata.vn/$photo";
                    }
                    $userMail = $member['email'];
                    // $userMail = 'phamviethungqnm@gmail.com';
                    $mailSubject = 'Ongbata thông báo ngày giỗ';
                    for ($i = 0; $i <= 7; $i++) {
                         $count ++;
                        $send_date = strtotime("+$i day", strtotime($today_lunar));
                        $send_date = date('d-m', $send_date);
                        if ($death_date_compare == $send_date) {
                            if ($i == 0) {
                                $mailNotify = "<h2>Kính báo anh/chị</h2>
                                <p>Hôm nay là ngày giỗ của thành viên <b></p>
                                <p><b> $lastname $firstname .</b></p>
                                <p>$weekday, ngày $death_date_compare-$today_lunar_year âm lịch.</p>";
                            } else {
                                $mailNotify = "<h2>Kính báo anh/chị,</h2>
                                <p>Còn <b>$i ngày</b> nữa là đến ngày giỗ của thành viên</p>
                                <p><b> $firstname $lastname.</b></p>
                                <p>$weekday, ngày $death_date_compare-$today_lunar_year âm lịch.</p>";
                            }
                            $mailBody = "
                                <!DOCTYPE html>
                                <html lang='en'>
                                <head>
                                    <meta charset='UTF-8'>
                                    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
                                    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                                    <title>Send mail page</title>
                                    <style>
                                        * {
                                            box-sizing: border-box;
                                        }
                                        p {
                                        margin: 8px 0;
                                        }
                                        img {
                                            width: 100%;
                                        }
                                        .text-center {
                                            text-align: center;
                                        }
                                        .align-center {
                                            align-items: center;
                                        }
                                        .fs-18 {
                                            font-size: 18px;
                                        }
                                        .fs-22 {
                                            font-size: 22px;
                                        }
                                        .fs-36 {
                                            font-size: 36px;
                                        }
                                        .d-flex {
                                            display: flex;
                                        }
                                        .p-top-bt-12 {
                                            padding: 12px 0px;
                                        }
                                        .p-top-bt-8 {
                                            padding: 8px 0px;
                                        }
                                        .w-100 {
                                            width: 100%;
                                        }
                                        .w-50 {
                                            width: 50%;
                                        }
                                        .border-bt {
                                            border-bottom: 1px solid white;
                                        }
                                        .border-right {
                                            border-right: 1px solid white;
                                        }
                                        .uppercase {
                                            text-transform: uppercase;
                                        }
                                        .container {
                                            width: 80%;
                                            margin: auto;
                                            border: 1px solid #ccc;
                                        }
                                        .header {
                                            padding: 12px;
                                        }
                                        .footer,
                                        .header {
                                            background-color: #0B730B;
                                            color: #fff;
                                        }
                                        .body {
                                            display: flex;
                                            border-top: 1px solid white;
                                            background-color: #7CE6E6;
                                            padding: 12px 48px;
                                        }
                                        .body_left {
                                            width: 70%;
                                            align-items: center;
                                            padding-right: 48px;
                                            padding-top: 24px;
                                        }
                                        .body_right {
                                            width: 30%;
                                        }
                                        .footer-lunar {
                                            border-right: 1px solid white;
                                        }
                                        .member_img img {
                                            border-radius: 50%;
                                        }
                                        .big-day {
                                            font-size: 75px;
                                        }
                                        
                                         .btn-profile {
                                                background: linear-gradient(184deg, #9c27b0, transparent);
                                                border: none;
                                                padding: 7px;
                                                border-radius: 4px;
                                        }
                                        
                                         .btn-profile a {
                                             text-decoration: none;
                                                color: white;
                                         }
                                    </style>
                                </head>
                                <body>
                                    <div class='container'>
                                        <div class='header fs-36 text-center uppercase'>
                                            Thông báo ngày giỗ
                                        </div>
                                        <div class='body text-center border-bt'>
                                            <div class='body_left fs-22'>
                                                $mailNotify
                                                <button class='btn-profile'>
                                                        <a href='$link_profile_email'>Xem chi tiết</a>
                                                </button>
                                            </div>
                                            <div class='body_right'>
                                                <div class='member_img'>
                                                    <img src='$link_photo' alt=''>
                                                </div>
                                                <div class='fs-22'><b>$death_date</b></div>
                                            </div>
                                        </div>
                                        <div class='footer d-flex w-100'>
                                            <div class='footer-lunar text-center w-50'>
                                                <div class='footer-top fs-22 p-top-bt-12 border-bt uppercase'>Âm lịch hôm nay</div>
                                                <div class='footer-bottom p-top-bt-12 fs-18 align-center'>
                                                    <div class='big-day'>$today_lunar_day</div>
                                                    <div>Tháng $today_lunar_month - $today_lunar_year</div>
                                                </div>
                                            </div>
                                            <div class='footer-solar text-center w-50'>
                                                <div class='footer-top fs-22 p-top-bt-12 border-bt uppercase'>Dương lịch hôm nay</div>
                                                <div class='footer-bottom p-top-bt-12 fs-18 align-center'>
                                                    <div class='big-day'>$solarDay</div>
                                                    <div>Tháng $solarMonth - $solarYear</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </body>
                                </html>
                                ";
                            echo "- $firstname $lastname: ";
                            sendEmail($userMail, $mailSubject, $mailBody);
                            echo "<br>";
                            sleep(10);
                        }
                    }
                  
                }
            }
        
        ?>

    </div>
    

</body>

</html>