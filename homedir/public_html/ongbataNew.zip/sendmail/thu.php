<!DOCTYPE html>
                                <html lang='en'>
                                <head>
                                    <meta charset='UTF-8'>
                                    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
                                    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                                    <title>Send mail page</title>
                                    <style>
                                        * {
                                            box-sizing: border-box;
                                        }
                                        p {
                                        margin: 8px 0;
                                        }
                                        img {
                                            width: 100%;
                                        }
                                        .text-center {
                                            text-align: center;
                                        }
                                        .align-center {
                                            align-items: center;
                                        }
                                        .fs-18 {
                                            font-size: 18px;
                                        }
                                        .fs-22 {
                                            font-size: 22px;
                                        }
                                        .fs-36 {
                                            font-size: 36px;
                                        }
                                        .d-flex {
                                            display: flex;
                                        }
                                        .p-top-bt-12 {
                                            padding: 12px 0px;
                                        }
                                        .p-top-bt-8 {
                                            padding: 8px 0px;
                                        }
                                        .w-100 {
                                            width: 100%;
                                        }
                                        .w-50 {
                                            width: 50%;
                                        }
                                        .border-bt {
                                            border-bottom: 1px solid white;
                                        }
                                        .border-right {
                                            border-right: 1px solid white;
                                        }
                                        .uppercase {
                                            text-transform: uppercase;
                                        }
                                        .container {
                                            width: 80%;
                                            margin: auto;
                                            border: 1px solid #ccc;
                                        }
                                        .header {
                                            padding: 12px;
                                        }
                                        .footer,
                                        .header {
                                            background-color: #0B730B;
                                            color: #fff;
                                        }
                                        .body {
                                            display: flex;
                                            border-top: 1px solid white;
                                            background-color: #7CE6E6;
                                            padding: 12px 48px;
                                        }
                                        .body_left {
                                            width: 70%;
                                            align-items: center;
                                            padding-right: 48px;
                                            padding-top: 24px;
                                        }
                                        .body_right {
                                            width: 30%;
                                        }
                                        .footer-lunar {
                                            border-right: 1px solid white;
                                        }
                                        .member_img img {
                                            border-radius: 50%;
                                        }
                                        .big-day {
                                            font-size: 75px;
                                        }
                                        .btn-profile {
                                                background: linear-gradient(184deg, #9c27b0, transparent);
                                                border: none;
                                                padding: 7px;
                                                border-radius: 4px;
                                        }
                                        
                                         .btn-profile a {
                                             text-decoration: none;
                                                color: white;
                                         }
                                    </style>
                                </head>
                                <body>
                                    <div class='container'>
                                        <div class='header fs-36 text-center uppercase'>
                                            Thông báo ngày giỗ
                                        </div>
                                        <div class='body text-center border-bt'>
                                            <div class='body_left fs-22'>
                                                <p>Hôm nay là ngày giỗ của thành viên <b></p>
                                                <button class="btn-profile">
                                                    <a href="">Xem chi tiết</a>
                                                </button>
                                            </div>
                                            <div class='body_right'>
                                                <div class='member_img'>
                                                    <img src='$link_photo' alt=''>
                                                </div>
                                                <div class='fs-22'><b>$death_date</b></div>
                                            </div>
                                        </div>
                                        <div class='footer d-flex w-100'>
                                            <div class='footer-lunar text-center w-50'>
                                                <div class='footer-top fs-22 p-top-bt-12 border-bt uppercase'>Âm lịch hôm nay</div>
                                                <div class='footer-bottom p-top-bt-12 fs-18 align-center'>
                                                    <div class='big-day'>$today_lunar_day</div>
                                                    <div>Tháng $today_lunar_month - $today_lunar_year</div>
                                                </div>
                                            </div>
                                            <div class='footer-solar text-center w-50'>
                                                <div class='footer-top fs-22 p-top-bt-12 border-bt uppercase'>Dương lịch hôm nay</div>
                                                <div class='footer-bottom p-top-bt-12 fs-18 align-center'>
                                                    <div class='big-day'>$solarDay</div>
                                                    <div>Tháng $solarMonth - $solarYear</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </body>
                                </html