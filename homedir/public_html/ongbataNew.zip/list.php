<?php
/*=======================================================/
	| Craeted By: Khalid puerto
	| URL: www.puertokhalid.com
	| Facebook: www.facebook.com/prof.puertokhalid
	| Instagram: www.instagram.com/khalidpuerto
	| Whatsapp: +212 654 211 360
 /======================================================*/

include __DIR__."/header.php";
?>

<div class="pt-list">
	<div class="pt-title">
		<span><i class="fas fa-list"></i></span> <b><?=$lang['listpage']['title']?></b>
		<?php if(us_email): ?>
		<div class="pt-options">
			<a href="<?=path?>/list.php?pg=my"><i class="fas fa-list"></i> <?=$lang['listpage']['my']?> của bạn</a>
		</div>
		<?php endif ?>
	</div>
<?php
$trees = (us_name? "&& (author = '{$lg}' || FIND_IN_SET('".us_email."', moderators) > 0) || FIND_IN_SET(".$getmobile.", moderators) > 0" : '');
$trees = (!us_name? "&& author = 0" : $trees);
if (!empty(us_email) && !empty(us_name)) {
	$sql = $db->query("SELECT * FROM ".prefix."families WHERE author = '{$lg}' || FIND_IN_SET('".us_email."', moderators) > 0 || FIND_IN_SET(".$getmobile.", moderators) > 0 LIMIT {$startpoint} , {$limit}") or die($db->error);
}
else {
	$sql = $db->query("SELECT * FROM ".prefix."families WHERE  status = 0 ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
}
if($sql->num_rows):

while($rs = $sql->fetch_assoc()):
	$rs['photo'] = $rs['photo'] ? $rs['photo'] : db_get("members", "photo", $rs['id'], 'family', "AND parent = '0'");
?>
<div class="pt-list-item">
	<div class="media">
		<div class="media-left">
			<div class="pt-thumb"><img src="<?=path."/".$rs['photo']?>" alt="<?=$rs['name']?>" onerror="this.src='<?=nophoto?>'"></div>
		</div>
		<div class="media-body">
			<h3><a href="<?=path?>/tree.php?id=<?=$rs['id']?>&t=<?=fh_seoURL($rs['name'])?>"><?=$rs['name']?></a></h3>
			<p><?=fh_ago($rs['date'])?></p>
			<div class="pt-options">
				<?php if((us_level && $rs['author'] == $lg) || us_level == 6): ?>
				<a class="pt-edit" rel="<?=$rs['id']?>"><i class="fas fa-edit"></i> <span><?=$lang['listpage']['edit']?></span></a>
				<?php endif; ?>
				<a class="pt-members"><i class="fas fa-users"></i> <span><b><?=db_count("members WHERE family = '{$rs['id']}'")?></b> <?=$lang['listpage']['members']?></span></a>
			</div>
		</div>
	</div>
</div>
<?php
endwhile;
$sql->close();
echo fh_pagination("families WHERE public = 0 {$trees} WHERE author = '{$lg}' || FIND_IN_SET('".us_email."', moderators) > 0 || FIND_IN_SET(".$getmobile.", moderators) > 0",$limit, path."/list.php?".($pg=='my'?'pg=my&':''));
else:
?>
<div class="pt-no-result"><i class="far fa-surprise"></i> <?=$lang['listpage']['no-result']?></div>
<?php
endif;
?>
</div>
</div>
<?php
include __DIR__."/footer.php";
?>
