<?php 
 include '../connectserve/connect.php';

    // delete coment
	if (isset($_GET['delete_comment'])) {
		$id = $_GET['id'];
		$sql = "DELETE  tb_react_comment, comment FROM comment LEFT JOIN tb_react_comment ON comment.comment_id=tb_react_comment.comment_id WHERE comment.comment_id ='".$id."'OR comment.parent_comment_id = ".$id;
		mysqli_query($connect, $sql);

		$demcomment = "SELECT COUNT(comment_id)AS numcomment FROM comment WHERE postid ='".$_GET['postid']."' ";
		$ketqua = mysqli_query($connect, $demcomment);
		while ($dem = mysqli_fetch_array($ketqua)){
			$numcommet_s= $dem['numcomment'];
		}
		echo $numcommet_s;
		exit();
	}
	if (isset($_GET['delete_comment_son'])) {
		$id = $_GET['id'];
		$sql = "DELETE  tb_react_comment, comment FROM comment LEFT JOIN tb_react_comment ON comment.comment_id=tb_react_comment.comment_id WHERE comment.comment_id ='".$id;
		mysqli_query($connect, $sql);

		$demcomment = "SELECT COUNT(comment_id)AS numcomment FROM comment WHERE postid ='".$_GET['postid']."' ";
		$ketqua = mysqli_query($connect, $demcomment);
		while ($dem = mysqli_fetch_array($ketqua)){
			$numcommet_s= $dem['numcomment'];
		}
		echo $numcommet_s;
		exit();
	}

?>